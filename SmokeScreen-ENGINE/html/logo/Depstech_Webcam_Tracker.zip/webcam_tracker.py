
import cv2
import mediapipe as mp
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import threading


class WebcamTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Depstech Webcam Face & Body Tracker")
        self.root.geometry("1000x700")
        self.root.resizable(False, False)

        self.video_label = tk.Label(self.root)
        self.video_label.pack(pady=10)

        self.control_frame = tk.Frame(self.root)
        self.control_frame.pack()

        self.start_button = tk.Button(
            self.control_frame,
            text="Start Tracking",
            font=("Arial", 14),
            command=self.start_camera,
            width=15
        )
        self.start_button.grid(row=0, column=0, padx=10)

        self.stop_button = tk.Button(
            self.control_frame,
            text="Stop Tracking",
            font=("Arial", 14),
            command=self.stop_camera,
            width=15,
            state="disabled"
        )
        self.stop_button.grid(row=0, column=1, padx=10)

        self.cap = None
        self.running = False

        # Mediapipe
        self.mp_face = mp.solutions.face_detection
        self.mp_pose = mp.solutions.pose
        self.face_detector = self.mp_face.FaceDetection(model_selection=1, min_detection_confidence=0.6)
        self.pose_detector = self.mp_pose.Pose(min_detection_confidence=0.6, min_tracking_confidence=0.6)

    def detect_camera(self):
        for index in range(5):
            cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
            if cap.isOpened():
                ret, _ = cap.read()
                if ret:
                    cap.release()
                    return index
                cap.release()
        return None

    def start_camera(self):
        cam_index = self.detect_camera()

        if cam_index is None:
            messagebox.showerror("Error", "Depstech Webcam not detected.")
            return

        self.cap = cv2.VideoCapture(cam_index, cv2.CAP_DSHOW)
        self.running = True
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

        threading.Thread(target=self.video_loop, daemon=True).start()

    def stop_camera(self):
        self.running = False
        if self.cap:
            self.cap.release()
        self.video_label.config(image='')
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")

    def video_loop(self):
        while self.running and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                break

            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # Face Detection
            face_results = self.face_detector.process(rgb_frame)
            if face_results.detections:
                for detection in face_results.detections:
                    bbox = detection.location_data.relative_bounding_box
                    h, w, _ = frame.shape
                    x = int(bbox.xmin * w)
                    y = int(bbox.ymin * h)
                    bw = int(bbox.width * w)
                    bh = int(bbox.height * h)
                    cv2.rectangle(frame, (x, y), (x + bw, y + bh), (0, 255, 0), 2)

            # Pose Detection (Upper Body Focus)
            pose_results = self.pose_detector.process(rgb_frame)
            if pose_results.pose_landmarks:
                h, w, _ = frame.shape
                for landmark_id in [11, 12, 13, 14, 15, 16]:
                    landmark = pose_results.pose_landmarks.landmark[landmark_id]
                    cx, cy = int(landmark.x * w), int(landmark.y * h)
                    cv2.circle(frame, (cx, cy), 5, (255, 0, 0), -1)

            img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            imgtk = ImageTk.PhotoImage(image=img)

            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)

        self.stop_camera()


if __name__ == "__main__":
    root = tk.Tk()
    app = WebcamTrackerApp(root)
    root.mainloop()
