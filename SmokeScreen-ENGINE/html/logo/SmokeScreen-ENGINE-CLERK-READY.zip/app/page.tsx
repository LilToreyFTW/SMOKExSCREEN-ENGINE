export default function Home() {
  return (
    <main style={{padding: "60px"}}>
      <h1>SmokeScreen SaaS Platform</h1>
      <p>Your SaaS + Digital Marketplace system is now fully integrated with Clerk authentication.</p>
    </main>
  );
}
